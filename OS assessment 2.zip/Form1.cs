﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace $safeprojectname$

{

    public partial class Form1 : Form

    {

        public Form1()

        {

            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)

        {

            if (listBox1.SelectedItem == listBox2.SelectedItem)

            {

                textBox2.Text = textBox1.Text;

            }

            if (listBox1.SelectedItem.ToString() == "Feet" && listBox2.SelectedItem.ToString() == "Inches")

            {

                textBox2.Text = (double.Parse(textBox2.Text) * 12).ToString();

            }

            if (listBox1.SelectedItem.ToString() == "Inches" && listBox2.SelectedItem.ToString() == "Feet")

            {

                textBox1.Text = (double.Parse(textBox2.Text) / 12).ToString();

            }

            if (listBox1.SelectedItem.ToString() == "Metres" && listBox2.SelectedItem.ToString() == "Feet")
            {

                textBox1.Text = (double.Parse(textBox2.Text) * 3.2808).ToString();

            }

            if (listBox1.SelectedItem.ToString() == "Metres" && listBox2.SelectedItem.ToString() == "Feet")

            {

                textBox1.Text = (double.Parse(textBox2.Text) * 3.2808).ToString();

            }

            if (listBox1.SelectedItem.ToString() == "Centimetres" && listBox2.SelectedItem.ToString() == "Feet")

            {

                textBox1.Text = (double.Parse(textBox2.Text) * 3.2808).ToString();

            }
            if (listBox1.SelectedItem.ToString() == "Kilometres" && listBox2.SelectedItem.ToString() == "Miles")

            {

                textBox1.Text = (double.Parse(textBox2.Text) / 0.621371).ToString();

            }
            if (listBox1.SelectedItem.ToString() == "Centimetres" && listBox2.SelectedItem.ToString() == "Inches")

            {

                textBox1.Text = (double.Parse(textBox2.Text) * 0.393701).ToString();

            }
            if (listBox1.SelectedItem.ToString() == "Celsius" && listBox2.SelectedItem.ToString() == "Fahrenheit")

            {

                textBox1.Text = (double.Parse(textBox2.Text) * 32).ToString();
            }
    }
}